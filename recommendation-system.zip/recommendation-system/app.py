import flask
import difflib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
import pandas as pd

app = flask.Flask(__name__, template_folder='templates')
kdrama=pd.read_csv("model\\kdrama_data.csv")

tfdif_vector = TfidfVectorizer(stop_words = 'english')
tfidf_matrix = tfdif_vector.fit_transform(kdrama['Synopsis'])
c=0

for c in range(0,len(kdrama['Name'])):
    kdrama['Name'][c]=kdrama['Name'][c].lower()
    c=c+1
sim_matrix = linear_kernel(tfidf_matrix, tfidf_matrix)
indicies = pd.Series(kdrama.index, index = kdrama['Name']).drop_duplicates()
all_titles = [kdrama['Name'][i].lower() for i in range(len(kdrama['Name']))]

def content_based_recommender(title,sim_scores = sim_matrix):
 idx = indicies[title]
 sim_scores = list(enumerate(sim_matrix[idx]))
 sim_scores = sorted(sim_scores, key = lambda x : x[1], reverse = True)
 sim_scores = sim_scores[1:13]
 kdrama_indices = [i[0] for i in sim_scores]
 kdrama_name = kdrama['Name'].iloc[kdrama_indices]
 kdrama_year = kdrama['Year of release'].iloc[kdrama_indices]
 kdrama_img = kdrama['image_source'].iloc[kdrama_indices]
 kdrama_syn = kdrama['Tags'].iloc[kdrama_indices]
 kdrama_epi = kdrama['Number of Episode'].iloc[kdrama_indices]
 kdrama_d = kdrama['Duration'].iloc[kdrama_indices]
 kdrama_g=  kdrama['Genre'].iloc[kdrama_indices]
 
 return_df = pd.DataFrame(columns=['Title','Year','img','synopsis','episodes','d'])
 return_df['Title'] = kdrama_name
 return_df['Year'] = kdrama_year
 return_df['img'] = kdrama_img
 return_df['synopsis']=kdrama_syn
 return_df['episodes']=kdrama_epi
 return_df['d']=kdrama_d
 return_df['g']=kdrama_g
 return return_df
@app.route('/', methods=['GET', 'POST'])
def main():
    if flask.request.method == 'GET':
        return(flask.render_template('index.html'))
            
    if flask.request.method == 'POST':
        m_name = flask.request.form['movie_name']
        m_name = m_name.lower()
        if m_name not in all_titles:
            return(flask.render_template('negative.html',name=m_name))
        else:
            print('True')
            result_final = content_based_recommender(m_name)
            names = []
            dates = []
            img=[]
            syn=[]
            epi=[]
            d=[]
            g=[]
            for i in range(0,len(result_final)):
                names.append(result_final.iloc[i][0])
                dates.append(result_final.iloc[i][1])
                img.append(result_final.iloc[i][2])
                syn.append(result_final.iloc[i][3])
                epi.append(result_final.iloc[i][4])
                d.append(result_final.iloc[i][5])
                g.append(result_final.iloc[i][6])

            for i in range(0,len(names)):
                names[i]=names[i].title()
            return flask.render_template('positive.html',movie_name=names,movie_date=dates,search_name=m_name,image_source=img,syn=syn,epi=epi,d=d,g=g)

if __name__ == '__main__':
    app.run(debug=True)
